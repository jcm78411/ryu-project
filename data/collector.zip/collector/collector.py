import time
import csv
import psutil
import subprocess
import platform
import socket


def obtener_gateway():
    gws = psutil.net_if_addrs()
    for interfaz, direcciones in gws.items():
        for direccion in direcciones:
            if direccion.family == socket.AF_INET:
                return direccion.address
    return None

def obtener_latencia(host):
    try:
        param = "-n" if platform.system().lower() == "windows" else "-c"
        resultado = subprocess.run(["ping", param, "1", host], capture_output=True, text=True)
        print("Salida capturada:")
        print(resultado.stdout)
        if resultado.returncode == 0:
            for linea in resultado.stdout.splitlines():
                if "tiempo=" in linea.lower():
                    tiempo = linea.lower().split("tiempo=")[1].split("ms")[0].strip()
                    print("Latencia encontrada:", tiempo, "ms")
                    return float(tiempo)
                elif "time=" in linea.lower():
                    tiempo = linea.lower().split("time=")[1].split("ms")[0].strip()
                    print("Latencia encontrada:", tiempo, "ms")
                    return float(tiempo)
        else:
            print("No se recibió respuesta del host, latencia = 0 ms")
    except Exception as e:
        print("Error obteniendo latencia:", e)
    return 0.0

def registrar_datos(interface_name, intervalo=2, archivo="datos_red.csv"):
    try:
        with open(archivo, mode='x', newline='') as f:
            escritor = csv.writer(f)
            escritor.writerow(["timestamp", "tx_bytes", "rx_bytes", "tx_packets", "rx_packets", "latencia"])
    except FileExistsError:
        pass

    # gateway = obtener_gateway()
    gateway = "192.168.116.100"
    if not gateway:
        print("No se pudo detectar la puerta de enlace.")
        return

    print(f"Usando {gateway} para medir latencia.")

    while True:
        stats = psutil.net_io_counters(pernic=True)

        if interface_name not in stats:
            print(f"No se encontró la interfaz: {interface_name}")
            return

        data = stats[interface_name]

        latencia = obtener_latencia(gateway)

        fila = [
            time.strftime("%Y-%m-%d %H:%M:%S"),
            data.bytes_sent,
            data.bytes_recv,
            data.packets_sent,
            data.packets_recv,
            latencia
        ]

        with open(archivo, mode='a', newline='') as f:
            escritor = csv.writer(f)
            escritor.writerow(fila)

        print(f"Datos guardados: {fila}")
        time.sleep(intervalo)

if __name__ == "__main__":
    registrar_datos(interface_name="Wi-Fi", intervalo=10)
